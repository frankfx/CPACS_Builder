package mouse;

import java.awt.Dimension;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JFrame;

public class MouseDemo extends JFrame implements MouseListener {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int x;
	private int y;
	
	public void initView(){
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		this.setMinimumSize(new Dimension(300, 300));
		
		addMouseListener(this);
		
        //Display the window.
        this.pack();
        this.setVisible(true);
	}
	
	@Override
	public void mouseClicked(MouseEvent pE) {
		//x = pE.getX();
		//y = pE.getY();
	}

	@Override
	public void mouseEntered(MouseEvent pE) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseExited(MouseEvent pE) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mousePressed(MouseEvent pE) {
		System.out.println("pressed");
		System.out.println(pE.getX());
		System.out.println(pE.getY());

	}

	@Override
	public void mouseReleased(MouseEvent pE) {
		System.out.println("released");
		System.out.println(pE.getX());
		System.out.println(pE.getY());
	}

	public static void main(String[] args) {
		javax.swing.SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				new MouseDemo().initView();
			}
		});
	}
}

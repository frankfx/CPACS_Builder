package matrix;

public class Matrix {
	// sets the square matrix mat to the identity matrix,
	// size refers to the number of rows (or columns)
	public static void setIdentityMatrix(float[] mat, int size) {

		// fill matrix with 0s
		for (int i = 0; i < size * size; ++i)
			mat[i] = 0.0f;

		// fill diagonal with 1s
		for (int i = 0; i < size; ++i)
			mat[i + i * size] = 1.0f;
	}

	//
	// a = a * b;
	//
	public static void multMatrix(float[] a, float[] b) {

		float[] res = new float[16];

		for (int i = 0; i < 4; ++i) {
			for (int j = 0; j < 4; ++j) {
				res[j * 4 + i] = 0.0f;
				for (int k = 0; k < 4; ++k) {
					res[j * 4 + i] += a[k * 4 + i] * b[j * 4 + k];
				}
			}
		}
		System.arraycopy(res, 0, a, 0, 16);
	}

	// Defines a transformation matrix mat with a translation
	public static void setTranslationMatrix(float[] mat, float x, float y, float z) {
		setIdentityMatrix(mat, 4);
		mat[12] = x;
		mat[13] = y;
		mat[14] = z;
	}
	
	public static void show(float a[]){
		int n = (int) Math.sqrt(a.length);
		
		for(int i=0; i<n; i++){
			System.out.print("|");
			for(int j=0; j<n; j++)
				System.out.printf("%5.1f", a[i*n+j]);
			System.out.println("  |");
		}
	}	
	
	public static void main(String[] args) {
		float[] mat = new float[]{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16};
		show(mat);
		System.out.println();
		
		setIdentityMatrix(mat, 4);
		show(mat);
		System.out.println();
		
		setTranslationMatrix(mat, 1,2,3);
		show(mat);
		System.out.println();		
		
	}
}

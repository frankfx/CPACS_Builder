package partner.business.training;

import java.util.ArrayList;
import java.util.Collection;

import org.junit.Before;
import org.junit.Test;

import static org.mockito.Mockito.*;
import static org.junit.Assert.*;
import framework.business.search.HQLQueryInterface;
import framework.service.ServiceFactory;
import framework.test.BaseStandaloneTest;

public class HQLStandaloneTest extends BaseStandaloneTest {
	
	private static final Long TEST_OID = 12364732647l;

	@Before
	public void vorbereitung() {
		HQLQueryInterface lMyMock = mock(HQLQueryInterface.class);
		Collection<Long> lSearchResults = new ArrayList<>();
		lSearchResults.add(TEST_OID);
		when(lMyMock.query(any(String.class))).thenReturn(lSearchResults);
		bind(HQLQueryInterface.class).toInstance(lMyMock).end();
	}
	
	@Test
	public void abfrageTesten() {
		PartnerService lService = ServiceFactory.getInstance(PartnerService.class);
		Collection<Long> lResult = lService.findOids();
		assertTrue(lResult.contains(TEST_OID));
	}

}

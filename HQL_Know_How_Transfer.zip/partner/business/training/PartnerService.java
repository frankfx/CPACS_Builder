package partner.business.training;

import java.util.Collection;

import framework.business.search.HQLQueryInterface;
import framework.service.ServiceFactory;

public class PartnerService {
	
	@SuppressWarnings("unchecked")
	public Collection<Long> findOids() {
		// Achtung: Hier wird die ServiceFactory genutzt, um im Test hier zu �berschreiben
		HQLQueryInterface lQI = ServiceFactory.getInstance(HQLQueryInterface.class);
		Collection lResult = lQI.query("select p.Oid from Partner p");
		return lResult;
	}

}

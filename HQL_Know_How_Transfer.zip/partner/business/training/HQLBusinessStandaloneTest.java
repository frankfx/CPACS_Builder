package partner.business.training;

import java.util.Collection;

import framework.business.search.QueryInterface;
import framework.business.search.QueryInterfaceFactory;
import framework.business.search.QueryParameterList;
import framework.loader.BusinessTransaction;
import framework.test.BusinessStandaloneTestCase;

public class HQLBusinessStandaloneTest extends BusinessStandaloneTestCase {
	
	// JUnit 3 Test
	public void testAbfragePruefen() throws Exception {
		processBusinessTransaction(new BusinessTransaction() {
			
			@Override
			public void run() throws Exception {
				
				String lHql = "select p from " + partner.business.PartnerModel.class.getName() + 
						" p join fetch p." + partner.business.PartnerModelMetaInfo.HQL_TelekomAdressen + 
						" a where p." + partner.business.PartnerModelMetaInfo.HQL_NameInternCaseInsensitive + 
						" = ? and a." + partner.business.TelekomAdresseModelMetaInfo.HQL_Bemerkung + 
						" is not null";
				
				QueryInterface lQI = QueryInterfaceFactory.getQueryInterface();
				QueryParameterList lParams = QueryInterfaceFactory.getQueryParameterList();
				lParams.addString("mueller");
				lQI.setMaxResults(100);
				Collection lResult = lQI.query(lHql, lParams);
				// Now this can be tested
			}
		});
	}

}

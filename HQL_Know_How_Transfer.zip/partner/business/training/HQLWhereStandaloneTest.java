package partner.business.training;

import java.util.Collection;

import partner.business.PartnerSearchModel;
import framework.base.SpezialType;
import framework.business.search.QueryInterface;
import framework.business.search.QueryInterfaceFactory;
import framework.business.search.QueryParameterList;
import framework.loader.BusinessTransaction;
import framework.test.BusinessStandaloneTestCase;

public class HQLWhereStandaloneTest extends BusinessStandaloneTestCase {
	
	public void testWhereCondition() throws Exception {
		processBusinessTransaction(new BusinessTransaction() {
			
			@Override
			public void run() throws Exception {
				
				PartnerSearchModel lPartnerSearch = new PartnerSearchModel();
				lPartnerSearch.setName("mueller");
				lPartnerSearch.setVipKennzeichen("" + SpezialType.GESCHUETZT.getId() + " | " + SpezialType.BESONDERSGESCHUETZT.getId());
				
				
				String lHql = "select p from " + partner.business.PartnerModel.class.getName() + 
						" p where ";
				QueryInterface lQI = QueryInterfaceFactory.getQueryInterface();
				QueryParameterList lParams = QueryInterfaceFactory.getQueryParameterList();
				String lWhereClause = lPartnerSearch.getWhereClauseForHql("p", lParams);
				System.out.println(lWhereClause);
				lQI.setMaxResults(100);
				Collection lResult = lQI.query(lHql + lWhereClause, lParams);
				// Now this can be tested
				System.out.println(lResult.size());
				System.out.println(lResult.iterator().next());
			}
		});
	}
}
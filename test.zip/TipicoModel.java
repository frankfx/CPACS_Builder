package test;


import java.sql.Date;


public class TipicoModel {
	private int mTnr;
	private String mTeam;
	private float mWinValue;
	private float mExpenses;
	private int mAttempts;
	private boolean mSuccess;

	public TipicoModel() {
		this(100, "Default", 0.0f, 0.0f, 0, false);
	}
	
	public TipicoModel(int pTnr, String pTeam, float pWinValue, float pExpenses, int pAttempts, boolean pSuccess){
		this.mTnr = pTnr;
		this.mTeam = pTeam;
		this.mWinValue = pWinValue;
		this.mExpenses = pExpenses;
		this.mAttempts = pAttempts;
		this.mSuccess = pSuccess;
	}
	
	public int getTnr() {
		return mTnr;
	}
	public void setTnr(int pTnr) {
		this.mTnr = pTnr;
	}
	public String getTeam() {
		return mTeam;
	}
	public void setTeam(String team) {
		this.mTeam = team;
	}
	public float getWinValue() {
		return mWinValue;
	}
	public void setWinValue(float pWinValue) {
		this.mWinValue = pWinValue;
	}
	public float getExpenses() {
		return mExpenses;
	}
	public void setExpenses(float pExpenses) {
		this.mExpenses = pExpenses;
	}
	public int getAttempts() {
		return mAttempts;
	}
	public void setAttempts(int lAttempts) {
		this.mAttempts = lAttempts;
	}
	
	public boolean getSuccess() {
		return mSuccess;
	}
	
	public void setSuccess(boolean lSuccess) {
		this.mSuccess = lSuccess;
	}
	
	
	@Override
	public boolean equals(Object obj) {
		return this.mTnr == ((TipicoModel)obj).getTnr();
	};
	
	@Override
	public String toString(){
		return "[" + mTnr + ", " + mTeam + ", " + mWinValue + ", " + mExpenses + ", " + mAttempts + ", " + mSuccess + "]" ;
	}
}



package test;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;
 



import javax.swing.*;
import javax.swing.table.*;
 
public class JTableDemo{
	public static int count = 0;
	
    public static void main( String[] args ){
        // Ein TableModel mit zuf�lligen Werten f�llen
        final TipicoTableModel model = new TipicoTableModel();
 
        // Die JTable initialisieren
        final JTable table = new JTable( model );
 
        // Der TableRowSorter wird die Daten des Models sortieren
        TableRowSorter<TableModel> sorter = new TableRowSorter<TableModel>();
 
        //table.setAutoCreateRowSorter(true);
        // Der Sorter muss dem JTable bekannt sein
        table.setRowSorter( sorter );
 
        // ... und der Sorter muss wissen, welche Daten er sortieren muss
        sorter.setModel( model );
 
        JButton button = new JButton("submit");
        button.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent pE) {
				model.addRow(new TipicoModel(count++, "Default", 0.0f, 0.0f, 0, false));
				System.out.println(model.list);
				model.fireTableDataChanged();
			}
		});
        
        JFrame frame = new JFrame( "Demo" );
        frame.getContentPane().setLayout(new BorderLayout());
        frame.getContentPane().add( new JScrollPane( table ), BorderLayout.CENTER);
        frame.getContentPane().add(button, BorderLayout.SOUTH);
        frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
        frame.pack();
        frame.setVisible( true );
    }
}


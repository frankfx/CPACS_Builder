package test;

import java.awt.Component;
import java.awt.Point;

import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

//Ein Renderer f�r java.awt.Point
public class PointRenderer extends DefaultTableCellRenderer{
 @Override
 public Component getTableCellRendererComponent( JTable table, Object value, 
         boolean isSelected, boolean hasFocus, int row, int column ) {
     Point point = (Point)value;
     String text = point.x + " / " + point.y;
     return super.getTableCellRendererComponent( table, text, isSelected,
         hasFocus,  row, column );
 }
}
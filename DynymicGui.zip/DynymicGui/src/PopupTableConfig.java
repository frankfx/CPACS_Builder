import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class PopupTableConfig extends JFrame {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int maxFilterSize = 4;
	private int curFilterSize = 0;
	
	public void initView(){
        // Create and set up the window.
        this.setTitle("Extras");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.getContentPane().setLayout(new GridLayout(maxFilterSize+2,1));
		
		JButton lExitButton = createExitButton();
        JButton lAddButton = createAddNewFilterRowButton();
		
		// Add control panel to add new filter rows or close the window
		JPanel lControlPanel = new JPanel();
		lControlPanel.setLayout(new GridLayout(1, 2));
		lControlPanel.add(lAddButton);
		lControlPanel.add(lExitButton);
		this.getContentPane().add(lControlPanel);        
        
		// Add first fixed filter row
		getContentPane().add(new FilterOperationModel(false).getFilterOperationModelPanel());
		
        //Display the window.
		this.setSize(new Dimension(400, 400));
		this.setResizable(false);
        this.setVisible(true);		
	}

	private JButton createExitButton(){
		JButton lExitButton = new JButton("Exit");
		
		lExitButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent pE) {
				dispose();
			}
		});        
        
		return lExitButton;
	}
	
	private JButton createAddNewFilterRowButton() {
		JButton lAddButton = new JButton();
        
        try {
			Image img = ImageIO.read(getClass().getResource("add_green.png")).getScaledInstance(50, 50, 1);
			lAddButton.setIcon(new ImageIcon(img));
		} catch (IOException ex) {
			lAddButton.setText("Add");
		}
        
        // Add listener to add a new filter row
		lAddButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent pE) {
				if(curFilterSize < maxFilterSize){
					final FilterOperationModel tempFilter = new FilterOperationModel(true);
					
					// Add listener to remove an existing filter row
					tempFilter.setRemoveButtonActionListener(new ActionListener() {
						@Override
						public void actionPerformed(ActionEvent pE) {
							getContentPane().remove(tempFilter.getFilterOperationModelPanel());
							revalidate();
							repaint();
							curFilterSize--;
						}
					});

					getContentPane().add(tempFilter.getFilterOperationModelPanel());
					revalidate();
					curFilterSize++;
				} else {
					System.out.println("row maximum reached");
				}
			}
		});
		return lAddButton;
	}
	
	public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
            	new PopupTableConfig().initView();
            }
        });
	}
}


public enum FilterConnectorType {
	AND, OR, NOT;
}

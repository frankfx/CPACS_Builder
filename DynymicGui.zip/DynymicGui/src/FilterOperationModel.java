import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.JTextField;


public class FilterOperationModel {
	private JPanel mMainPanel;
	private JButton mRemoveButton;
	private JTextField mFilterValue;
	private JComboBox<ColumnType> mTableColumn;
	private JComboBox<FilterOpsType> mFilterOperation;
	private JComboBox<FilterConnectorType> mFilterConnector;
	
	public FilterOperationModel(boolean pShowRemoveButton) {
		mTableColumn = new JComboBox<ColumnType>();
		mTableColumn.addItem(ColumnType.ID);
		mTableColumn.addItem(ColumnType.TEAM);
		mTableColumn.addItem(ColumnType.EXPENSES);
		mTableColumn.addItem(ColumnType.WINVALUE);
		mTableColumn.addItem(ColumnType.SUCCESS);
		
		mFilterOperation = new JComboBox<FilterOpsType>();
		mFilterOperation.addItem(FilterOpsType.GLEICH);
		mFilterOperation.addItem(FilterOpsType.UNGLEICH);
		mFilterOperation.addItem(FilterOpsType.KLEINER);
		mFilterOperation.addItem(FilterOpsType.KLEINER_GLEICH);
		mFilterOperation.addItem(FilterOpsType.GROESSER);
		mFilterOperation.addItem(FilterOpsType.GROESSER_GLEICH);
		
		mFilterConnector = new JComboBox<FilterConnectorType>();
		mFilterConnector.addItem(null);
		mFilterConnector.addItem(FilterConnectorType.AND);
		mFilterConnector.addItem(FilterConnectorType.OR);

		mFilterValue = new JTextField();
		mRemoveButton = new JButton();
		
		mMainPanel = new JPanel();
		mMainPanel.setLayout(new GridLayout());
		mMainPanel.add(mTableColumn);
		mMainPanel.add(mFilterOperation);
		mMainPanel.add(mFilterValue);
		mMainPanel.add(mFilterConnector);
		mMainPanel.add(mRemoveButton);
		
		if(pShowRemoveButton){
	        try {
				Image img = ImageIO.read(getClass().getResource("minus_red.png")).getScaledInstance(25, 25, 1);
				mRemoveButton.setIcon(new ImageIcon(img));
			} catch (IOException ex) {
				mRemoveButton.setText("Remove");
			}		
		} else {
			mRemoveButton.setVisible(false);
		}
	}
	
	public JPanel getFilterOperationModelPanel(){
		return mMainPanel;
	}
	
	public void setRemoveButtonActionListener(ActionListener l){
		this.mRemoveButton.addActionListener(l);
	}
}


public enum ColumnType {
	ID, TEAM, WINVALUE, EXPENSES, ATTEMPTS, DATE, SUCCESS;
}

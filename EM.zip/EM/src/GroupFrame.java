import java.awt.BorderLayout;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;


public class GroupFrame extends DefaultFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
	public GroupFrame(String pTitle, int pWidth, int pHeight) {
		super(pTitle, pWidth, pHeight);
	}

	@Override
	public void addContentPanel(Object [] args){
		JPanel content = getContent();
		gbConstraints.gridy = gbConstraints.gridy + 1;
		panelMain.add(content, gbConstraints);
		this.revalidate();
	}
	
	private JPanel getContent() {
		JPanel panelResult = new JPanel();
		panelResult.setLayout(new BorderLayout());
		panelResult.setBorder(BorderFactory.createTitledBorder("title"));
		panelResult.add(new JLabel("Team1"), BorderLayout.WEST);
		panelResult.add(new JLabel("3 : 4", SwingConstants.CENTER), BorderLayout.CENTER);
		panelResult.add(new JLabel("Team2"), BorderLayout.EAST);
		return panelResult;
	}	

	public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
            	new GroupFrame("Gruppe A", 400, 400).initView();
            }
        });
	}	
}

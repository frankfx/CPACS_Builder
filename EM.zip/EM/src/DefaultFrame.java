import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;

public abstract class DefaultFrame extends JFrame{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String mTitle;
	private int mWidth;
	private int mHeight;
	protected JPanel panelMain;
	protected GridBagConstraints gbConstraints;
	
	public DefaultFrame(String pTitle, int pWidth, int pHeight){
		mTitle = pTitle;
		mWidth = pWidth;
		mHeight = pHeight;
		panelMain = new JPanel();
		gbConstraints = new GridBagConstraints();
		gbConstraints.gridy = 0;
		gbConstraints.fill = GridBagConstraints.HORIZONTAL;
		gbConstraints.weightx = 0.1;
	}
	
	public abstract void addContentPanel(Object [] args);
	
	public void initView(){
        // Create and set up the window.
        this.setTitle(mTitle);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.getContentPane().setLayout(new BorderLayout());
		
		this.addComponents();
		
        //Display the window.
		this.setSize(new Dimension(mWidth, mHeight));
		this.setResizable(false);
        this.setVisible(true);		
	}

	private void addComponents() {
		this.getContentPane().add(createPanelHeader(), BorderLayout.NORTH);
		this.getContentPane().add(createPanelMain(), BorderLayout.CENTER);
		this.getContentPane().add(createPanelFooter(), BorderLayout.SOUTH);
	}
	
	private Component createPanelMain() {
		JScrollPane scrollPane = new JScrollPane (panelMain, 
	            ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
	            ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		
		JButton btnAddContent = new JButton("add");
		btnAddContent.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent pE) {
				addContentPanel(null);
			}
		});
		
		panelMain.setBackground(Color.WHITE);
		panelMain.setLayout(new GridBagLayout());
		panelMain.add(btnAddContent);
		
		return scrollPane;
	}

	private Component createPanelFooter() {
		JPanel panelFooter = new JPanel();
		panelFooter.setBackground(Color.BLACK);
		return panelFooter;
	}


	private JPanel createPanelHeader(){
		JPanel panelHeader = new JPanel();
		JLabel lGroupLabel = new JLabel(mTitle);
		lGroupLabel.setForeground(Color.WHITE);
		lGroupLabel.setFont(new Font("Serif", Font.BOLD, 30));
		panelHeader.setLayout(new GridBagLayout());
		panelHeader.setBackground(Color.RED);
		panelHeader.add(lGroupLabel);
		
		return panelHeader;
	}
}

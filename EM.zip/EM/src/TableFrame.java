import java.awt.BorderLayout;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;


public class TableFrame extends DefaultFrame {

	public TableFrame(String pTitle, int pWidth, int pHeight) {
		super(pTitle, pWidth, pHeight);
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public void addContentPanel(Object [] args){
		JPanel content = getContent();
		gbConstraints.gridy = gbConstraints.gridy + 1;
		panelMain.add(content, gbConstraints);
		this.revalidate();
	}
	
	private JPanel getContent() {
		JPanel panelResult = new JPanel();
		panelResult.setLayout(new BorderLayout());
		panelResult.setBorder(BorderFactory.createTitledBorder("title"));
		panelResult.add(new JLabel("1"), BorderLayout.WEST);
		panelResult.add(new JLabel("BDR", SwingConstants.CENTER), BorderLayout.CENTER);
		panelResult.add(new JLabel("19 Pkt."), BorderLayout.EAST);
		return panelResult;
	}	

	public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
            	new GroupFrame("Tabelle Gruppe A", 100, 100).initView();
            }
        });
	}

}
